import pyvista as pv
import numpy as np

class HandModel:
    def __init__(self):
        # 手指长度比例（相对值）
        self.finger_lengths = {
            'thumb': [4.0, 3.0],  # 大拇指两节
            'index': [4.0, 3.0, 2.0],  # 食指三节
            'middle': [4.5, 3.5, 2.5],  # 中指三节
            'ring': [4.2, 3.2, 2.2],  # 无名指三节
            'pinky': [3.5, 2.5, 1.5]   # 小指三节
        }
        
        # 关节球体半径
        self.joint_radius = 0.3
        # 手指骨节半径
        self.bone_radius = 0.2
        # 手掌尺寸
        self.palm_size = [4.0, 5.0, 1.0]  # 宽、高、厚
        
        # 初始化PyVista网格对象
        self.palm = None
        self.joints = {}
        self.bones = {}
        
        self.create_hand_model()
    
    def create_sphere(self, center, radius):
        """创建关节球体"""
        sphere = pv.Sphere(radius=radius, center=center)
        return sphere
    
    def create_cylinder(self, start_point, end_point, radius):
        """创建骨节圆柱体"""
        direction = np.array(end_point) - np.array(start_point)
        length = np.linalg.norm(direction)
        direction = direction / length
        
        cylinder = pv.Cylinder(
            center=(np.array(start_point) + np.array(end_point)) / 2,
            direction=direction,
            radius=radius,
            height=length
        )
        return cylinder
    
    def create_hand_model(self):
        """创建完整的手部模型"""
        # 创建手掌
        self.palm = pv.Box(bounds=(-self.palm_size[0]/2, self.palm_size[0]/2,
                                 -self.palm_size[1]/2, self.palm_size[1]/2,
                                 -self.palm_size[2]/2, self.palm_size[2]/2))
        
        # 创建手指
        base_positions = {
            'thumb': [-self.palm_size[0]/2, -self.palm_size[1]/3, 0],
            'index': [-self.palm_size[0]/4, self.palm_size[1]/2, 0],
            'middle': [0, self.palm_size[1]/2, 0],
            'ring': [self.palm_size[0]/4, self.palm_size[1]/2, 0],
            'pinky': [self.palm_size[0]/2, self.palm_size[1]/2, 0]
        }
        
        for finger, lengths in self.finger_lengths.items():
            current_pos = base_positions[finger]
            self.joints[finger] = []
            self.bones[finger] = []
            
            # 创建关节和骨节
            for i, length in enumerate(lengths):
                # 创建关节球体
                joint = self.create_sphere(current_pos, self.joint_radius)
                self.joints[finger].append(joint)
                
                # 计算下一个关节位置
                next_pos = np.array(current_pos) + np.array([0, length, 0])
                
                # 创建骨节圆柱体
                if i < len(lengths):
                    bone = self.create_cylinder(current_pos, next_pos, self.bone_radius)
                    self.bones[finger].append(bone)
                
                current_pos = next_pos
    
    def update_finger_angle(self, finger, joint_idx, angle):
        """更新指定手指关节的角度"""
        # TODO: 实现角度更新逻辑
        pass
    
    def get_model_meshes(self):
        """获取所有模型网格"""
        meshes = [self.palm]
        for finger in self.joints:
            meshes.extend(self.joints[finger])
            meshes.extend(self.bones[finger])
        return meshes
