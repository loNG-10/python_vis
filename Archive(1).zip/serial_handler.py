import serial
import serial.tools.list_ports
import threading
import logging
import re
import time

logger = logging.getLogger(__name__)

class SerialHandler:
    def __init__(self, data_callback):
        self.angle_serial = None
        self.pressure_serial = None
        self.data_callback = data_callback
        self.running = False
        self.threads = []
    
    def get_available_ports(self):
        """获取可用的串口列表"""
        ports = []
        for port in serial.tools.list_ports.comports():
            ports.append(port.device)
        return ports
    
    def connect_angle_port(self, port, baudrate=115200):
        """连接角度数据串口"""
        try:
            self.angle_serial = serial.Serial(port, baudrate, timeout=1)
            logger.info(f"角度数据串口连接成功: {port}")
            return True
        except Exception as e:
            logger.error(f"角度数据串口连接失败: {str(e)}")
            return False
    
    def connect_pressure_port(self, port, baudrate=115200):
        """连接压力数据串口"""
        try:
            self.pressure_serial = serial.Serial(port, baudrate, timeout=1)
            logger.info(f"压力数据串口连接成功: {port}")
            return True
        except Exception as e:
            logger.error(f"压力数据串口连接失败: {str(e)}")
            return False
    
    def parse_angle_data(self, data):
        """解析角度数据
        数据格式: C1=77.2,C2=88.5,...
        """
        try:
            values = {}
            pairs = data.strip().split(',')
            for pair in pairs:
                channel, value = pair.split('=')
                values[channel] = float(value)
            return values
        except Exception as e:
            logger.error(f"角度数据解析错误: {str(e)}")
            return None
    
    def parse_pressure_data(self, data):
        """解析压力数据
        数据格式: float值以逗号分隔
        """
        try:
            values = [float(x) for x in data.strip().split(',')]
            return values
        except Exception as e:
            logger.error(f"压力数据解析错误: {str(e)}")
            return None
    
    def read_angle_data(self):
        """读取角度数据的线程函数"""
        while self.running and self.angle_serial:
            try:
                if self.angle_serial.in_waiting:
                    data = self.angle_serial.readline().decode().strip()
                    parsed_data = self.parse_angle_data(data)
                    if parsed_data:
                        self.data_callback('angle', parsed_data)
            except Exception as e:
                logger.error(f"读取角度数据错误: {str(e)}")
                time.sleep(0.1)
    
    def read_pressure_data(self):
        """读取压力数据的线程函数"""
        while self.running and self.pressure_serial:
            try:
                if self.pressure_serial.in_waiting:
                    data = self.pressure_serial.readline().decode().strip()
                    parsed_data = self.parse_pressure_data(data)
                    if parsed_data:
                        self.data_callback('pressure', parsed_data)
            except Exception as e:
                logger.error(f"读取压力数据错误: {str(e)}")
                time.sleep(0.1)
    
    def start(self):
        """启动数据读取"""
        self.running = True
        if self.angle_serial:
            angle_thread = threading.Thread(target=self.read_angle_data)
            angle_thread.daemon = True
            angle_thread.start()
            self.threads.append(angle_thread)
        
        if self.pressure_serial:
            pressure_thread = threading.Thread(target=self.read_pressure_data)
            pressure_thread.daemon = True
            pressure_thread.start()
            self.threads.append(pressure_thread)
    
    def stop(self):
        """停止数据读取"""
        self.running = False
        if self.angle_serial:
            self.angle_serial.close()
        if self.pressure_serial:
            self.pressure_serial.close()
        
        for thread in self.threads:
            thread.join()
        
        self.threads.clear()
        logger.info("串口通信已停止")
