import tkinter as tk
from tkinter import ttk
import logging
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.figure import Figure
import matplotlib
import datetime

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class DataGloveVisualizer:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("数据手套可视化系统")
        self.root.geometry("1200x800")
        
        # 初始化视角参数
        self.view_elev = 20
        self.view_azim = 45
        self.update_interval = 33  # 默认30FPS
        
        # 初始化颜色方案
        self.finger_colors = {
            'finger_0': '#FF99CC',  # 大拇指
            'finger_1': '#FF9999',  # 食指
            'finger_2': '#99FF99',  # 中指
            'finger_3': '#9999FF',  # 无名指
            'finger_4': '#FFFF99'   # 小指
        }
        
        # 初始化角度和压力数据
        self.angle_data = {}
        self.angle_data["finger_1"] = [30, 40, 50]  # 食指
        self.angle_data["finger_2"] = [35, 45, 55]  # 中指
        self.angle_data["finger_3"] = [40, 50, 60]  # 无名指
        self.angle_data["finger_4"] = [45, 55, 65]  # 小指
        self.angle_data["finger_0"] = [180]*2  # 大拇指只有两个值
        self.pressure_data = [0]*5
        
        # 创建主分割窗口
        self.main_frame = ttk.Frame(self.root)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 创建上部控制面板
        self.control_frame = ttk.LabelFrame(self.main_frame, text="控制面板")
        self.control_frame.pack(fill=tk.X, padx=10, pady=5)
        
        # 添加控制按钮
        self.init_control_panel()
        
        # 创建左侧和右侧分割窗口
        self.left_frame = ttk.Frame(self.main_frame)
        self.right_frame = ttk.Frame(self.main_frame)
        
        self.left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # 3D可视化区域
        self.frame_3d = ttk.LabelFrame(self.left_frame, text="3D手部模型")
        self.frame_3d.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 数据监控区域
        self.frame_data = ttk.Notebook(self.right_frame)
        self.frame_data.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 初始化各个组件
        self.init_3d_view()
        self.init_data_tab()
        
        logger.info("应用程序初始化完成")

    def create_hand_model(self, angles=None, pressures=None):
        """使用 Matplotlib 创建手部模型"""
        if angles is None:
            angles = self.angle_data
        if pressures is None:
            pressures = [50]*5  # 默认压力
        
        fig = Figure(figsize=(8, 8), dpi=100)
        ax = fig.add_subplot(111, projection='3d')
        
        # 手掌参数
        palm_width = 0.3  # 缩小手掌宽度
        palm_height = 0.5  # 缩小手掌高度
        palm_depth = 0.08  # 减小手掌厚度
        
        # 绘制手掌（使用多个点来形成手掌形状）
        palm_x = np.array([-palm_width/2, palm_width/2, palm_width/2, -palm_width/2, -palm_width/2])
        palm_y = np.array([0, 0, palm_height, palm_height, 0])
        palm_z = np.array([0, 0, 0, 0, 0])
        ax.plot_surface(
            palm_x.reshape(5, 1), 
            palm_y.reshape(5, 1), 
            palm_z.reshape(5, 1) + palm_depth/2,
            color='#FFE5CC',  # 更柔和的肤色
            alpha=0.8
        )
        
        # 定义手指位置和方向（相对于手掌的位置）
        finger_positions = [
            (-0.12, palm_height, 0),    # 食指
            (-0.04, palm_height, 0),    # 中指
            (0.04, palm_height, 0),     # 无名指
            (0.12, palm_height, 0)      # 小指
        ]
        
        # 绘制手指
        for i, (x, y, z) in enumerate(finger_positions):
            finger_key = f'finger_{i+1}'
            finger_angles = angles[finger_key]
            finger_color = self.finger_colors[finger_key]
            
            # 计算每个关节的位置
            joint_lengths = [0.12, 0.10, 0.08]  # 更真实的手指长度比例
            current_x, current_y, current_z = x, y, z
            
            # 绘制整个手指的轮廓
            finger_points_x = [current_x]
            finger_points_y = [current_y]
            finger_points_z = [current_z]
            
            for j, (angle, length) in enumerate(zip(finger_angles, joint_lengths)):
                # 计算下一个关节位置
                radians = np.deg2rad(angle)
                next_x = current_x
                next_y = current_y + length * np.cos(radians)
                next_z = current_z + length * np.sin(radians)
                
                # 存储点位置
                finger_points_x.extend([next_x])
                finger_points_y.extend([next_y])
                finger_points_z.extend([next_z])
                
                # 绘制关节（球体）
                joint_size = 60 * (1-j*0.2)  # 缩小关节球体
                ax.scatter([current_x], [current_y], [current_z], 
                         color=finger_color, s=joint_size, alpha=0.8)
                
                # 绘制骨节（圆柱体）
                if j < len(finger_angles)-1:
                    ax.plot([current_x, next_x], 
                           [current_y, next_y], 
                           [current_z, next_z],
                           color=finger_color, 
                           linewidth=3*(1-j*0.2),  # 减小线宽
                           alpha=0.8)
                
                current_x, current_y, current_z = next_x, next_y, next_z
            
            # 根据压力值添加颜色渐变效果
            pressure = pressures[i+1] / 100.0
            # 创建从基础颜色到红色的渐变
            base_color = np.array(matplotlib.colors.to_rgb(finger_color))
            highlight_color = np.array([1, 0, 0])  # 红色
            mixed_color = base_color * (1-pressure) + highlight_color * pressure
            
            ax.scatter(finger_points_x, finger_points_y, finger_points_z,
                      color=mixed_color, alpha=0.3 + pressure * 0.7, s=30)
        
        # 绘制大拇指（特殊处理）
        thumb_pos = (-palm_width/2 - 0.02, palm_height*0.3, 0)  # 调整大拇指位置
        thumb_angles = angles['finger_0']
        current_x, current_y, current_z = thumb_pos
        thumb_color = self.finger_colors['finger_0']
        
        # 大拇指的两个关节
        joint_lengths = [0.12, 0.10]  # 调整大拇指长度
        for j, (angle, length) in enumerate(zip(thumb_angles, joint_lengths)):
            radians = np.deg2rad(angle)
            next_x = current_x - length * np.cos(radians) * 0.5
            next_y = current_y + length * np.cos(radians)
            next_z = current_z + length * np.sin(radians)
            
            # 绘制关节
            joint_size = 60 * (1-j*0.2)  # 缩小关节球体
            ax.scatter([current_x], [current_y], [current_z], 
                      color=thumb_color, s=joint_size, alpha=0.8)
            
            # 绘制骨节
            ax.plot([current_x, next_x], 
                   [current_y, next_y], 
                   [current_z, next_z],
                   color=thumb_color, 
                   linewidth=3*(1-j*0.2),  # 减小线宽
                   alpha=0.8)
            
            current_x, current_y, current_z = next_x, next_y, next_z
        
        # 设置视角和显示范围
        ax.view_init(elev=self.view_elev, azim=self.view_azim)
        ax.set_xlim(-0.8, 0.8)  # 调整显示范围
        ax.set_ylim(-0.3, 1.0)
        ax.set_zlim(-0.5, 0.8)
        
        # 设置标签
        ax.set_xlabel('X轴')
        ax.set_ylabel('Y轴')
        ax.set_zlabel('Z轴')
        
        # 添加标题
        ax.set_title('手部模型可视化')
        
        # 优化显示效果
        ax.grid(False)  # 移除网格线
        ax.xaxis.pane.fill = False  # 移除背景平面
        ax.yaxis.pane.fill = False
        ax.zaxis.pane.fill = False
        
        return fig

    def init_3d_view(self):
        """初始化3D视图"""
        # 创建初始手部模型
        initial_hand_fig = self.create_hand_model()
        
        # 在Tkinter中嵌入Matplotlib图形
        self.canvas = FigureCanvasTkAgg(initial_hand_fig, master=self.frame_3d)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        logger.info("3D视图初始化完成")

    def update_hand_model(self, angles=None, pressures=None):
        """更新手部模型"""
        # 清除当前图形
        for widget in self.frame_3d.winfo_children():
            widget.destroy()
        
        # 创建新的手部模型
        new_hand_fig = self.create_hand_model(angles, pressures)
        
        # 重新嵌入Tkinter
        self.canvas = FigureCanvasTkAgg(new_hand_fig, master=self.frame_3d)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    def init_data_tab(self):
        """初始化数据监控标签页"""
        # 创建角度数据标签页
        self.tab_angles = ttk.Frame(self.frame_data)
        self.frame_data.add(self.tab_angles, text="角度数据")
        
        # 创建压力数据标签页
        self.tab_pressure = ttk.Frame(self.frame_data)
        self.frame_data.add(self.tab_pressure, text="压力数据")
        
        # 为每个手指创建角度显示
        self.angle_labels = {}
        finger_names = ["大拇指", "食指", "中指", "无名指", "小指"]
        
        for i, name in enumerate(finger_names):
            frame = ttk.LabelFrame(self.tab_angles, text=name)
            frame.pack(fill=tk.X, padx=5, pady=5)
            
            labels = []
            for j in range(3 if i > 0 else 2):  # 大拇指2个关节，其他3个
                label = ttk.Label(frame, text=f"关节{j+1}: 0°")
                label.pack(padx=5, pady=2)
                labels.append(label)
            
            self.angle_labels[f"finger_{i}"] = labels
        
        # 为每个手指创建压力显示
        self.pressure_bars = {}
        
        for i, name in enumerate(finger_names):
            frame = ttk.LabelFrame(self.tab_pressure, text=name)
            frame.pack(fill=tk.X, padx=5, pady=5)
            
            # 创建进度条
            var = tk.DoubleVar()
            bar = ttk.Progressbar(frame, length=200, mode='determinate', variable=var)
            bar.pack(padx=5, pady=5)
            
            # 创建数值标签
            label = ttk.Label(frame, text="0%")
            label.pack()
            
            self.pressure_bars[f"finger_{i}"] = (bar, label, var)
        
        logger.info("数据监控标签页初始化完成")

    def update_data_display(self, angles, pressures):
        """更新数据显示"""
        # 更新角度显示
        for finger_id, angle_list in angles.items():
            labels = self.angle_labels[finger_id]
            for i, angle in enumerate(angle_list):
                if i < len(labels):  # 确保不超出标签数量
                    labels[i].config(text=f"关节{i+1}: {angle:.1f}°")
        
        # 更新压力显示
        for i, pressure in enumerate(pressures):
            finger_id = f"finger_{i}"
            if finger_id in self.pressure_bars:
                bar, label, var = self.pressure_bars[finger_id]
                var.set(pressure)
                label.config(text=f"{pressure:.1f}%")

    def init_control_panel(self):
        """初始化控制面板"""
        # 创建按钮框架
        btn_frame = ttk.Frame(self.control_frame)
        btn_frame.pack(side=tk.LEFT, padx=5, pady=5)
        
        # 视角控制按钮
        view_frame = ttk.LabelFrame(btn_frame, text="视角控制")
        view_frame.pack(side=tk.LEFT, padx=5)
        
        ttk.Button(view_frame, text="正视图", command=lambda: self.set_view(0, 0)).pack(side=tk.LEFT, padx=2)
        ttk.Button(view_frame, text="侧视图", command=lambda: self.set_view(0, 90)).pack(side=tk.LEFT, padx=2)
        ttk.Button(view_frame, text="俯视图", command=lambda: self.set_view(90, 0)).pack(side=tk.LEFT, padx=2)
        
        # 更新频率控制
        freq_frame = ttk.LabelFrame(btn_frame, text="更新频率(FPS)")
        freq_frame.pack(side=tk.LEFT, padx=5)
        
        self.fps_var = tk.StringVar(value="30")
        fps_combo = ttk.Combobox(freq_frame, textvariable=self.fps_var, values=["1", "5", "10", "30", "60"], width=5)
        fps_combo.pack(side=tk.LEFT, padx=2)
        fps_combo.bind("<<ComboboxSelected>>", self.update_frequency)
        
        # 数据记录控制
        record_frame = ttk.LabelFrame(btn_frame, text="数据记录")
        record_frame.pack(side=tk.LEFT, padx=5)
        
        self.record_btn = ttk.Button(record_frame, text="开始记录", command=self.toggle_recording)
        self.record_btn.pack(side=tk.LEFT, padx=2)
        
        # 配置保存/加载
        config_frame = ttk.LabelFrame(btn_frame, text="配置")
        config_frame.pack(side=tk.LEFT, padx=5)
        
        ttk.Button(config_frame, text="保存配置", command=self.save_config).pack(side=tk.LEFT, padx=2)
        ttk.Button(config_frame, text="加载配置", command=self.load_config).pack(side=tk.LEFT, padx=2)

    def set_view(self, elev, azim):
        """设置视角"""
        self.view_elev = elev
        self.view_azim = azim
        self.update_hand_model(self.angle_data, self.pressure_data)

    def update_frequency(self, event=None):
        """更新刷新频率"""
        try:
            fps = int(self.fps_var.get())
            self.update_interval = int(1000 / fps)  # 转换为毫秒
            logger.info(f"更新频率设置为 {fps} FPS")
        except ValueError:
            logger.error("无效的FPS值")
            self.fps_var.set("30")
            self.update_interval = 33

    def toggle_recording(self):
        """切换数据记录状态"""
        if not hasattr(self, 'is_recording'):
            self.is_recording = False
            self.recorded_data = []
        
        self.is_recording = not self.is_recording
        if self.is_recording:
            self.record_btn.configure(text="停止记录")
            logger.info("开始记录数据")
        else:
            self.record_btn.configure(text="开始记录")
            self.save_recorded_data()
            logger.info("停止记录数据")

    def save_recorded_data(self):
        """保存记录的数据"""
        if hasattr(self, 'recorded_data') and self.recorded_data:
            import json
            from datetime import datetime
            
            filename = f"sensor_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(filename, 'w') as f:
                json.dump(self.recorded_data, f)
            logger.info(f"数据已保存到 {filename}")
            self.recorded_data = []

    def save_config(self):
        """保存当前配置"""
        import json
        config = {
            'view_elev': self.view_elev,
            'view_azim': self.view_azim,
            'update_interval': self.update_interval,
            'colors': self.finger_colors
        }
        with open('hand_config.json', 'w') as f:
            json.dump(config, f)
        logger.info("配置已保存")

    def load_config(self):
        """加载配置"""
        import json
        try:
            with open('hand_config.json', 'r') as f:
                config = json.load(f)
            self.view_elev = config.get('view_elev', 20)
            self.view_azim = config.get('view_azim', 45)
            self.update_interval = config.get('update_interval', 33)
            self.finger_colors = config.get('colors', self.finger_colors)
            self.update_hand_model(self.angle_data, self.pressure_data)
            fps = int(1000 / self.update_interval)
            self.fps_var.set(str(fps))
            logger.info("配置已加载")
        except FileNotFoundError:
            logger.warning("未找到配置文件")

    def run(self):
        # 启动模拟传感器数据的方法
        def simulate_sensor_data():
            try:
                # 获取当前数据
                current_angles = self.angle_data.copy()
                current_pressures = self.pressure_data.copy()
                
                # 生成目标数据
                target_angles = {
                    'finger_0': [np.random.randint(0, 90), np.random.randint(0, 90)],
                    'finger_1': [np.random.randint(0, 90), np.random.randint(0, 90), np.random.randint(0, 90)],
                    'finger_2': [np.random.randint(0, 90), np.random.randint(0, 90), np.random.randint(0, 90)],
                    'finger_3': [np.random.randint(0, 90), np.random.randint(0, 90), np.random.randint(0, 90)],
                    'finger_4': [np.random.randint(0, 90), np.random.randint(0, 90), np.random.randint(0, 90)]
                }
                target_pressures = [np.random.randint(0, 100) for _ in range(5)]
                
                # 计算插值
                alpha = 0.1  # 插值系数
                new_angles = {}
                for finger_id, angles in target_angles.items():
                    current = current_angles[finger_id]
                    new_angles[finger_id] = [
                        current[i] + (target - current[i]) * alpha
                        for i, target in enumerate(angles)
                    ]
                
                new_pressures = [
                    current + (target - current) * alpha
                    for current, target in zip(current_pressures, target_pressures)
                ]
                
                # 更新数据
                self.angle_data = new_angles
                self.pressure_data = new_pressures
                
                # 如果正在记录，保存数据
                if hasattr(self, 'is_recording') and self.is_recording:
                    self.recorded_data.append({
                        'timestamp': datetime.now().isoformat(),
                        'angles': new_angles,
                        'pressures': new_pressures
                    })
                
                # 更新显示
                self.update_hand_model(new_angles, new_pressures)
                self.update_data_display(new_angles, new_pressures)
                
                # 计划下一次更新
                self.root.after(self.update_interval, simulate_sensor_data)
                
            except Exception as e:
                logger.error(f"模拟传感器数据时发生错误: {e}", exc_info=True)
                self.root.after(5000, simulate_sensor_data)

        try:
            # 启动模拟
            simulate_sensor_data()
            
            # 启动主循环
            self.root.mainloop()
        except Exception as e:
            logger.error(f"应用程序运行时发生严重错误: {e}", exc_info=True)
            # 尝试优雅地关闭应用程序
            self.root.quit()

if __name__ == "__main__":
    app = DataGloveVisualizer()
    app.run()
